#include <PubSubClient.h>

void setup()
{
Serial.begin(9600); // send and receive at 9600 baud
}

int number = 0;

void loop()
{
Serial.print("Number is ");
Serial.println(number); // print the number
delay(500); // delay half second between numbers
number++; // to the next number
}
